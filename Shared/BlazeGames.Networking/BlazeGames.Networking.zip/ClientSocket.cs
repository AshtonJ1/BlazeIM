﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;

namespace BlazeGames.Networking
{
    delegate void ClientSocketPacketReceived_Handler(object sender, ClientSocket clientSocket, Packet pak);

    class ClientSocket : IDisposable
    {
        public long
            SentPackets = 0,
            ReceivedPackets = 0;

        public event ClientSocketPacketReceived_Handler ClientSocketPacketReceived_Event;
        public event EventHandler ClientSocketConnected_Event;
        public event EventHandler ClientSocketDisconnected_Event;

        public System.Net.Sockets.Socket RawSocket;
        private byte[] ReceiveBuffer = new byte[Packet.MaxLength];
        private IPEndPoint EP;

        public ClientSocket(IPEndPoint EP)
        {
            RawSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            this.EP = EP;
        }

        public ClientSocket(IPAddress IP, int Port)
        {
            RawSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            this.EP = new IPEndPoint(IP, Port);
        }

        public void Connect()
        {
            try
            {
                RawSocket.BeginConnect(EP, new AsyncCallback(SocketConnected), RawSocket);
            }
            catch { }
        }

        public void Disconnect()
        {
            RawSocket.BeginDisconnect(false, new AsyncCallback(SocketDisconnected), RawSocket);
        }

        public void SendPacket(Packet pak)
        {
            RawSocket.BeginSend(pak.ToArray(), 0, pak.Length, SocketFlags.None, new AsyncCallback(PacketSent), RawSocket);
        }

        public void SendBuffer(byte[] Buffer)
        {
            RawSocket.BeginSend(Buffer, 0, Buffer.Length, SocketFlags.None, new AsyncCallback(PacketSent), RawSocket);
        }

        private void SocketConnected(IAsyncResult ar)
        {
            try
            {
                RawSocket.EndConnect(ar);
                RawSocket.BeginReceive(ReceiveBuffer, 0, Packet.MaxLength, SocketFlags.None, new AsyncCallback(PacketReceived), RawSocket);
            }
            catch { }

            if(ClientSocketConnected_Event != null)
                ClientSocketConnected_Event(this, null);
        }

        private void SocketDisconnected(IAsyncResult ar)
        {
            RawSocket.EndDisconnect(ar);

            if(ClientSocketDisconnected_Event != null)
                ClientSocketDisconnected_Event(this, null);
        }

        private void PacketSent(IAsyncResult ar)
        {
            RawSocket.EndSend(ar);
            SentPackets++;
        }

        private void PacketReceived(IAsyncResult ar)
        {
            try
            {
                int ReceiveSize = RawSocket.EndReceive(ar);

                if (ReceiveSize > 0)
                {
                    byte[] TMPReceiveBuffer = new byte[Packet.MaxLength];
                    Array.Copy(ReceiveBuffer, TMPReceiveBuffer, Packet.MaxLength);

                    RawSocket.BeginReceive(ReceiveBuffer, 0, Packet.MaxLength, SocketFlags.None, new AsyncCallback(PacketReceived), RawSocket);

                    Packet[] ReceivePakets = Packet.SplitPackets(TMPReceiveBuffer);
                    foreach (Packet ReceivePak in ReceivePakets)
                    {
                        if(ClientSocketPacketReceived_Event != null)
                            ClientSocketPacketReceived_Event(this, this, ReceivePak);

                        ReceivedPackets++;
                    }
                }
                else { if (ClientSocketDisconnected_Event != null) { ClientSocketDisconnected_Event(this, null); } }
            }
            catch { if (ClientSocketDisconnected_Event != null) { ClientSocketDisconnected_Event(this, null); } }
        }

        /* GC */
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                RawSocket.Dispose();
            }
        }
    }
}
